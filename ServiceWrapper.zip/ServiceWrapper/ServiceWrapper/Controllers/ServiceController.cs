﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ServiceWrapper.Controllers
{
    public class ServiceController : ApiController
    {
        // GET api/service
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/service/xml
        public Object Get(string id)
        {

            System.Web.HttpContext.Current.Response.Headers.Add(HttpRequestHeader.Accept.ToString(), "application/xml");
            if(id.ToLowerInvariant() == "xml")
            {

                GlobalConfiguration.Configuration.Formatters.XmlFormatter.UseXmlSerializer = true;

                var response = new CustomResponse { Data = "Your Test Data", DataType = "xml", Success = true };

                return Request.CreateResponse(HttpStatusCode.OK, response, GlobalConfiguration.Configuration.Formatters.XmlFormatter);

                
            }

            return Request.CreateResponse(HttpStatusCode.BadRequest);

        }


        // POST api/service/id
        public Object Post(string id, [FromBody]string value)
        {
            var response = new CustomResponse { Data = "Your Test Data", Success = true };

            if(id == "xml")
            {
                response.DataType = "XML";
                return Request.CreateResponse(HttpStatusCode.OK, response, GlobalConfiguration.Configuration.Formatters.XmlFormatter);
                
            }
            else
            {
                response.DataType = "JSON";
                return Request.CreateResponse(HttpStatusCode.OK, response, GlobalConfiguration.Configuration.Formatters.JsonFormatter);
                
            }
            
        }

        // PUT api/service/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/service/5
        public void Delete(int id)
        {
        }

        [Serializable]
        public class CustomResponse
        {
            public string DataType { get; set; }
            public string Data { get; set; }
            public bool Success { get; set; }
        }
    }
}
