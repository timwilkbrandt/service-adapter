﻿/// <reference path="service-adapter.js" />

document.addEventListener("DOMContentLoaded", function (event) {
   



    //GET
    var bttnGet = document.getElementById('bttnGet');
    bttnGet.addEventListener('click', function () {
        var sa = new serviceAdapter();
        sa.settings.url = 'api/service';
        sa.qsParameters.add('foo', 1);
        sa.settings.contentType = 'application/json';
        sa.callbacks.customSuccessCallback = function (e)
        {
            console.group('in custom get callback!'); console.log(e); console.groupEnd();
            console.group('response types:');
            console.log(sa.responseData);
            console.log(sa.responseJson);
            console.log(sa.responseText);
            console.log(sa.responseXML);
            console.groupEnd();
        };
        sa.get();

    });

    //GETJSON
    var bttnGetJson = document.getElementById('bttnGetJson');
    bttnGetJson.addEventListener('click', function () {
        var sa = new serviceAdapter();
        sa.settings.url = 'api/service';
        sa.callbacks.customSuccessCallback = function (e) {
            console.group('in custom getjson callback!'); console.log(sa.responseJson); console.groupEnd();
        };
        sa.getJson();
    });


    //GETXML
    var bttnGetXml = document.getElementById('bttnGetXml');
    bttnGetXml.addEventListener('click', function () {

        var sa = new serviceAdapter();
        sa.settings.url = 'api/service/xml';
        sa.callbacks.customSuccessCallback = function (e) {
            console.group('in custom getxml callback!'); console.log(sa.responseXml); console.groupEnd();
        };
        sa.getXml();

    });

    //POST
    var bttnPost = document.getElementById('bttnPost');
    bttnPost.addEventListener('click', function () {

        var sa = new serviceAdapter();
        sa.settings.url = 'api/service/json';
        sa.settings.contentType = 'application/json';
        sa.enctype = 'text/plain';
        sa.isJson = true;
        sa.callbacks.customSuccessCallback = function (e) {
            console.group('in custom post callback!'); console.log(e); console.groupEnd();
            console.group('response types:');
            console.log(sa.responseData);
            console.log(sa.responseJson);
            console.log(sa.responseText);
            console.log(sa.responseXML);
            console.groupEnd();
        };
        sa.post();

    });


    //POSTJSON
    var bttnPostJson = document.getElementById('bttnPostJson');
    bttnPostJson.addEventListener('click', function () {
        var sa = new serviceAdapter();
        sa.settings.url = 'api/service/json';
        sa.enctype = 'text/plain';
        sa.callbacks.customSuccessCallback = function (e) {
            console.group('in custom postJson callback!'); console.log(e); console.groupEnd();
            console.group('response types:');
            console.log(sa.responseData);
            console.log(sa.responseJson);
            console.log(sa.responseText);
            console.log(sa.responseXML);
            console.groupEnd();
        };
        sa.post();

    });

    //POSTXML
    var bttnPostXml = document.getElementById('bttnPostXml');
    bttnPostXml.addEventListener('click', function () {

        var sa = new serviceAdapter();
        sa.settings.url = 'api/service/xml';
        sa.enctype = 'text/plain';
        sa.callbacks.customSuccessCallback = function (e) {
            console.group('in custom postXml callback!'); console.log(e); console.groupEnd();
            console.group('response types:');
            console.log(sa.responseData);
            console.log(sa.responseJson);
            console.log(sa.responseText);
            console.log(sa.responseXML);
            console.groupEnd();
        };
        sa.post();

    });

});


function publicfoo() {

    this.publicDosomething = function () {

        privateDosomething();
    };

    function privateDosomething() { };

};